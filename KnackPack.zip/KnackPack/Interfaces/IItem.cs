namespace KnackPack.Interfaces
{
    public interface IItem
    {
        string Name { get; }

        double Weight { get; }
    }
}