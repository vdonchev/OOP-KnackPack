﻿namespace KnackPack.Interfaces
{
    public interface ILaptop : IElectronic
    {
        double ScreenSize { get; }
    }
}