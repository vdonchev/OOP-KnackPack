﻿namespace KnackPack.Models.Items
{
    public enum SleeveType
    {
        Short,
        Long
    }
}