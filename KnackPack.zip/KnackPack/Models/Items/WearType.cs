﻿namespace KnackPack.Models.Items
{
    public enum WearType
    {
        Male,
        Female
    }
}